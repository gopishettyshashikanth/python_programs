import json
sourcefile = open("testdata.json","rU")
json_data = json.load(sourcefile)
#print(json_data["data"])

#print(json_data)
for i in json_data["data"]:
    #print(i)
    row_array = []
    row_array.append(i)
    print("Taluka_Code",row_array[0]["value"][0][0]["Taluka_Code"])
    print("Mobile_ID : ", row_array[0]["value"][0][0]["Mobile_ID"])
    print("Financial_Year : ",row_array[0]["value"][0][0]["Financial_Year"])


    #row_array.append(json_data["data"])

    # for attribute in i:
    #     row_array.append(i[attribute])
    #     print(row_array)


    # print(row_array[0][0]["value"][0][0]["Taluka_Code"])
    # print(row_array[0][0]["value"][0][0]["Mobile_ID"])
    # # for attribute in i:
    #     row_array.append(i[attribute])
    #     print(row_array)


